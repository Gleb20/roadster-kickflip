import {BOOSTERS,activeBooster} from './boosters.js?v=4.3.0';
export function createBoosterPainter(){
 const images=Object.fromEntries(Object.keys(BOOSTERS).map(id=>[id,new Image()]));
 function load(){return Promise.all(Object.entries(images).map(([id,img])=>new Promise((resolve,reject)=>{img.onload=()=>img.decode().then(resolve,reject);img.onerror=reject;img.src=new URL('../assets/boosters/'+id+'.png',import.meta.url).href;})));}
 function drawPickups(ctx,q,{px,ground,scale,time,reduced=false}){
  for(const o of q.pickups){const x=px+o.x*scale,y=ground-o.y*scale,r=29*scale;if(x< -60||x>ctx.canvas.width+60)continue;
   ctx.save();ctx.translate(x,y+(reduced?0:Math.sin(time*3+o.uid)*3*scale));
   const glow=ctx.createRadialGradient(0,0,r*.3,0,0,r*1.6);glow.addColorStop(0,BOOSTERS[o.id].color+'40');glow.addColorStop(1,BOOSTERS[o.id].color+'00');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,r*1.6,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#192a3866';ctx.strokeStyle=BOOSTERS[o.id].color;ctx.lineWidth=1.4*scale;ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.fill();ctx.stroke();
   ctx.strokeStyle='#fff9';ctx.lineWidth=1.5*scale;ctx.beginPath();ctx.arc(-r*.08,-r*.08,r*.76,3.7,4.6);ctx.stroke();
   ctx.scale(reduced?1:Math.cos(time*2.6+o.uid*.4),1);ctx.drawImage(images[o.id],-r*.83,-r*.83,r*1.66,r*1.66);ctx.restore();
  }
 }
 function aura(ctx,q,{x,y,scale,time,reduced=false}){
  if(!activeBooster(q,'shield'))return;
  const warning=q.active.shield<2;ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);
  ctx.globalAlpha=warning&&!reduced?.45+.35*(.5+.5*Math.sin(time*9)):.8;ctx.strokeStyle='#9cf4ff';ctx.lineWidth=2;ctx.shadowColor='#7ce5f3';ctx.shadowBlur=18*scale;
  ctx.fillStyle='#7ce5f30b';ctx.beginPath();ctx.ellipse(0,-76,68,112,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.shadowBlur=0;ctx.strokeStyle='#7ce5f344';ctx.beginPath();ctx.ellipse(0,-76,74,118,0,0,Math.PI*2);ctx.stroke();ctx.restore();
 }
 return {load,drawPickups,aura};
}
